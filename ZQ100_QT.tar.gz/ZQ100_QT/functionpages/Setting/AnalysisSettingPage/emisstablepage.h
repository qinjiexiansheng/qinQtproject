#ifndef LEMISSTABLEPAGE_H
#define LEMISSTABLEPAGE_H

#include <QDialog>

class EmissTablePage : public QDialog
{
    Q_OBJECT

public:
    EmissTablePage(QWidget *parent = 0);
    ~EmissTablePage();
};

#endif // LEMISSTABLEPAGE_H
