#ifndef OPERATIONFILE_H
#define OPERATIONFILE_H

#define Update_TempAd_Table   54
#define Effect_TempAd_Table   55
#define Table_To_SD           56
#define SD_To_Table           57

#endif // OPERATIONFILE_H
