<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AskDialog</name>
    <message>
        <location filename="view/smallwidget.cpp" line="498"/>
        <source>NO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="504"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="484"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutoSavePictureWidget</name>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="209"/>
        <location filename="view/autosavepicturewidget.cpp" line="281"/>
        <source>Auto Save Picture</source>
        <translation type="unfinished">自动保存图片</translation>
    </message>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="291"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BasicSchema</name>
    <message>
        <location filename="schema/basicschema.cpp" line="8"/>
        <source>BasicSchema</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Camera</name>
    <message>
        <location filename="service/camera.cpp" line="21"/>
        <location filename="service/camera.cpp" line="26"/>
        <source>The picture has been saved as %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CorrectSchema</name>
    <message>
        <location filename="schema/correctschema.cpp" line="8"/>
        <source>CorrectModel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DateTimeWidget</name>
    <message>
        <location filename="view/datetimewidget.cpp" line="1144"/>
        <location filename="view/datetimewidget.cpp" line="1183"/>
        <source>DateTime</source>
        <translation type="unfinished">时间日期</translation>
    </message>
</context>
<context>
    <name>DenoiseMode</name>
    <message>
        <location filename="service/imagedenoise.cpp" line="16"/>
        <source>Noise reduction has been shut down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="service/imagedenoise.cpp" line="36"/>
        <source>Noise reduction has been started</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DenoiseSchema</name>
    <message>
        <location filename="schema/denoiseschema.cpp" line="15"/>
        <source>Image Denoise</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DigitKeyboard</name>
    <message>
        <location filename="view/softkeyboard.cpp" line="18"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="24"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="30"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="36"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="42"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="48"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="54"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="60"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="66"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="72"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="78"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="84"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="90"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="96"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="102"/>
        <source>.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="108"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplaySchema</name>
    <message>
        <location filename="schema/displayschema.cpp" line="8"/>
        <source>Display Setting</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EmissivityTableWidget</name>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="274"/>
        <location filename="view/emissivitytablewidget.cpp" line="301"/>
        <source>Emissivity Table</source>
        <translation type="unfinished">辐射率表</translation>
    </message>
</context>
<context>
    <name>GearSchema</name>
    <message>
        <location filename="schema/gearschema.cpp" line="16"/>
        <source>Gear Setting</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GearSetWidget</name>
    <message>
        <location filename="view/gearsetwidget.cpp" line="226"/>
        <location filename="view/gearsetwidget.cpp" line="260"/>
        <source>Gear Setting</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GlobalParamWidget</name>
    <message>
        <location filename="view/globalparamwidget.cpp" line="651"/>
        <source>Global Param Setting</source>
        <translation type="unfinished">全局参数设置</translation>
    </message>
</context>
<context>
    <name>HexadecimalKeyboard</name>
    <message>
        <location filename="view/softkeyboard.cpp" line="283"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="289"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="295"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="301"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="307"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="313"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="319"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="325"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="331"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="337"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="343"/>
        <source>a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="349"/>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="355"/>
        <source>c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="361"/>
        <source>d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="367"/>
        <source>e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="373"/>
        <source>f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="379"/>
        <source>.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="385"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="391"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="397"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="403"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/softkeyboard.cpp" line="409"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageFreeSchema</name>
    <message>
        <location filename="schema/imagefreeschema.cpp" line="8"/>
        <source>Image Free</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfraredMode</name>
    <message>
        <location filename="service/infraredmode.cpp" line="17"/>
        <source>Switched to iron red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="service/infraredmode.cpp" line="37"/>
        <source>Switched to anti iron red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="service/infraredmode.cpp" line="56"/>
        <source>Switched to white hot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="service/infraredmode.cpp" line="75"/>
        <source>Switched to black fever</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="service/infraredmode.cpp" line="94"/>
        <source>Switched to feather red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="service/infraredmode.cpp" line="113"/>
        <source>Switched to rainbow</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfraredSchema</name>
    <message>
        <location filename="schema/infraredschema.cpp" line="29"/>
        <source>Infrared Setting</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LanguageWidget</name>
    <message>
        <location filename="view/languagewidget.cpp" line="412"/>
        <source>Language Setting</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="view/mainwindow.cpp" line="167"/>
        <source>Shutting Down!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/mainwindow.cpp" line="225"/>
        <source>Does it shut down?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/mainwindow.cpp" line="587"/>
        <source>Video is filming!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModifyAdTableWidget</name>
    <message>
        <location filename="view/modifyadtablewidget.cpp" line="14"/>
        <location filename="view/modifyadtablewidget.cpp" line="86"/>
        <source>ModifyAdTable[%1]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PictureBrowingWidget</name>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="601"/>
        <source>Picture Browing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="710"/>
        <source>The picture will be deleted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PowerManageWidget</name>
    <message>
        <location filename="view/powermanagewidget.cpp" line="485"/>
        <source>Power Manage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatAutoSavePicturePage</name>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="167"/>
        <source>%1 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="171"/>
        <source>%1 Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="173"/>
        <source>%1 Minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="177"/>
        <source>%1 Minute %2 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="179"/>
        <source>%1 Minutes %2 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatAutoSavePictureSmallWidget</name>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="14"/>
        <location filename="view/autosavepicturewidget.cpp" line="97"/>
        <location filename="view/autosavepicturewidget.cpp" line="124"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="25"/>
        <location filename="view/autosavepicturewidget.cpp" line="98"/>
        <location filename="view/autosavepicturewidget.cpp" line="126"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/autosavepicturewidget.cpp" line="36"/>
        <location filename="view/autosavepicturewidget.cpp" line="99"/>
        <location filename="view/autosavepicturewidget.cpp" line="129"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatData</name>
    <message>
        <location filename="model/satdata.cpp" line="91"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="model/satdata.cpp" line="91"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatDateTimeListWidget</name>
    <message>
        <location filename="view/datetimewidget.cpp" line="8"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="9"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="10"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="11"/>
        <location filename="view/datetimewidget.cpp" line="152"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatDateTimePageOne</name>
    <message>
        <location filename="view/datetimewidget.cpp" line="179"/>
        <location filename="view/datetimewidget.cpp" line="438"/>
        <source>Add Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="180"/>
        <location filename="view/datetimewidget.cpp" line="440"/>
        <source>Sub Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="181"/>
        <location filename="view/datetimewidget.cpp" line="442"/>
        <source>Add Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="182"/>
        <location filename="view/datetimewidget.cpp" line="444"/>
        <source>Sub Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="183"/>
        <location filename="view/datetimewidget.cpp" line="446"/>
        <source>Add Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="184"/>
        <location filename="view/datetimewidget.cpp" line="448"/>
        <source>Sub Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="185"/>
        <location filename="view/datetimewidget.cpp" line="450"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="186"/>
        <location filename="view/datetimewidget.cpp" line="453"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatDateTimePageThree</name>
    <message>
        <location filename="view/datetimewidget.cpp" line="954"/>
        <location filename="view/datetimewidget.cpp" line="1118"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="955"/>
        <location filename="view/datetimewidget.cpp" line="1120"/>
        <source>Reelect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="956"/>
        <location filename="view/datetimewidget.cpp" line="1122"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatDateTimePageThreeListWidget</name>
    <message>
        <location filename="view/datetimewidget.cpp" line="753"/>
        <source>BeiJing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatDateTimePageTwo</name>
    <message>
        <location filename="view/datetimewidget.cpp" line="480"/>
        <location filename="view/datetimewidget.cpp" line="721"/>
        <source>Add Hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="481"/>
        <location filename="view/datetimewidget.cpp" line="723"/>
        <source>Sub Hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="482"/>
        <location filename="view/datetimewidget.cpp" line="725"/>
        <source>Add Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="483"/>
        <location filename="view/datetimewidget.cpp" line="727"/>
        <source>Sub Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="484"/>
        <location filename="view/datetimewidget.cpp" line="729"/>
        <source>Add Second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="485"/>
        <location filename="view/datetimewidget.cpp" line="731"/>
        <source>Sub Second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="486"/>
        <location filename="view/datetimewidget.cpp" line="733"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/datetimewidget.cpp" line="487"/>
        <location filename="view/datetimewidget.cpp" line="736"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatEmissivityTablePage</name>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="173"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="173"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="173"/>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="173"/>
        <source>Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="173"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="180"/>
        <source>Asphaltum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="180"/>
        <location filename="view/emissivitytablewidget.cpp" line="181"/>
        <location filename="view/emissivitytablewidget.cpp" line="182"/>
        <location filename="view/emissivitytablewidget.cpp" line="183"/>
        <location filename="view/emissivitytablewidget.cpp" line="185"/>
        <location filename="view/emissivitytablewidget.cpp" line="186"/>
        <location filename="view/emissivitytablewidget.cpp" line="187"/>
        <location filename="view/emissivitytablewidget.cpp" line="188"/>
        <location filename="view/emissivitytablewidget.cpp" line="189"/>
        <location filename="view/emissivitytablewidget.cpp" line="195"/>
        <source>Nonmetal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="181"/>
        <source>Brick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="182"/>
        <source>Calcimine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="183"/>
        <source>Ceramics(vase type)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="184"/>
        <source>Copper Wire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="184"/>
        <location filename="view/emissivitytablewidget.cpp" line="190"/>
        <location filename="view/emissivitytablewidget.cpp" line="191"/>
        <location filename="view/emissivitytablewidget.cpp" line="192"/>
        <location filename="view/emissivitytablewidget.cpp" line="193"/>
        <location filename="view/emissivitytablewidget.cpp" line="194"/>
        <source>Metal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="185"/>
        <source>Diode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="186"/>
        <source>Fire resistance brick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="187"/>
        <source>Graphite(lamp black)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="188"/>
        <source>Glass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="189"/>
        <source>Glass(surface)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="190"/>
        <source>Liquid Steel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="191"/>
        <source>Mercury</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="192"/>
        <source>Sheet metal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="193"/>
        <source>Stainless Stell 310(25Cr,20Ni)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="194"/>
        <source>Steel(oxidizing at 600c\260c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="195"/>
        <source>Ransistor(plastics sealed)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatEmissivityTableSmallWidget</name>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="13"/>
        <source>MoveUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="24"/>
        <source>MoveDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="35"/>
        <source>LeftShift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="46"/>
        <source>RightShift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="57"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/emissivitytablewidget.cpp" line="68"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatGearSetListWidget</name>
    <message>
        <location filename="view/gearsetwidget.cpp" line="12"/>
        <location filename="view/gearsetwidget.cpp" line="51"/>
        <source>Gear One</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/gearsetwidget.cpp" line="21"/>
        <location filename="view/gearsetwidget.cpp" line="52"/>
        <source>Gear Two</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatGearSetPage</name>
    <message>
        <location filename="view/gearsetwidget.cpp" line="185"/>
        <location filename="view/gearsetwidget.cpp" line="205"/>
        <source>  The first gear


  Measuring range:


	-20Â°C~250Â°C



</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/gearsetwidget.cpp" line="187"/>
        <location filename="view/gearsetwidget.cpp" line="207"/>
        <source>  The second gear


  Measuring range:


	200Â°C~1000Â°C



</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatGlobalParamListWidget</name>
    <message>
        <location filename="view/globalparamwidget.cpp" line="11"/>
        <source>Emissivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="20"/>
        <source>Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="29"/>
        <source>Environment Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="38"/>
        <source>Reflection Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="47"/>
        <source>Relative Humidity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="56"/>
        <source>Correction Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="65"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="74"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="192"/>
        <source>Function not implemented!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatGlobalParamPage</name>
    <message>
        <location filename="view/globalparamwidget.cpp" line="468"/>
        <source>Emissivity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="471"/>
        <source>Distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="478"/>
        <source>Environment Temp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="486"/>
        <source>Reflection Temp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="494"/>
        <source>Relative Humidity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="497"/>
        <source>Correction Temp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="619"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="625"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="614"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatGlobalParamSmallWidget</name>
    <message>
        <location filename="view/globalparamwidget.cpp" line="220"/>
        <location filename="view/globalparamwidget.cpp" line="316"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="231"/>
        <location filename="view/globalparamwidget.cpp" line="318"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/globalparamwidget.cpp" line="242"/>
        <location filename="view/globalparamwidget.cpp" line="320"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatLanguageListWidget</name>
    <message>
        <location filename="view/languagewidget.cpp" line="9"/>
        <location filename="view/languagewidget.cpp" line="137"/>
        <source>English</source>
        <translation>英语</translation>
    </message>
    <message>
        <location filename="view/languagewidget.cpp" line="10"/>
        <source>Chinese</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatLanguagePage</name>
    <message>
        <location filename="view/languagewidget.cpp" line="322"/>
        <source>Load the language?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/languagewidget.cpp" line="165"/>
        <location filename="view/languagewidget.cpp" line="181"/>
        <location filename="view/languagewidget.cpp" line="320"/>
        <source>Load</source>
        <translation>加载</translation>
    </message>
    <message>
        <location filename="view/languagewidget.cpp" line="166"/>
        <location filename="view/languagewidget.cpp" line="189"/>
        <location filename="view/languagewidget.cpp" line="327"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/languagewidget.cpp" line="167"/>
        <location filename="view/languagewidget.cpp" line="197"/>
        <location filename="view/languagewidget.cpp" line="330"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatMainSmallWidget</name>
    <message>
        <location filename="view/userwidget.cpp" line="184"/>
        <source>Schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/userwidget.cpp" line="195"/>
        <source>Photo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/userwidget.cpp" line="206"/>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/userwidget.cpp" line="217"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/userwidget.cpp" line="228"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/userwidget.cpp" line="359"/>
        <source>Function not implemented!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatPictureBrowingSmallWidget</name>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="460"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="471"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="482"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="493"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatPictureLabel</name>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="254"/>
        <source>Image loading error!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatPictureViewSmallWidget</name>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="12"/>
        <source>Enlarge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="23"/>
        <source>Narrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="34"/>
        <source>MoveUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="45"/>
        <source>MoveDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="56"/>
        <source>LeftShift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="67"/>
        <source>RightShift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="79"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="91"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/picturebrowingwidget.cpp" line="102"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatPowerManageListWidget</name>
    <message>
        <location filename="view/powermanagewidget.cpp" line="8"/>
        <source>Screen Saver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="9"/>
        <source>Timing Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="10"/>
        <location filename="view/powermanagewidget.cpp" line="162"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatPowerManagePageOne</name>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="595"/>
        <location filename="view/systemcontrolwidget.cpp" line="710"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="596"/>
        <location filename="view/systemcontrolwidget.cpp" line="712"/>
        <source>1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="597"/>
        <location filename="view/systemcontrolwidget.cpp" line="714"/>
        <source>5 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="598"/>
        <location filename="view/systemcontrolwidget.cpp" line="716"/>
        <source>10 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="599"/>
        <location filename="view/systemcontrolwidget.cpp" line="718"/>
        <source>30 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="600"/>
        <location filename="view/systemcontrolwidget.cpp" line="720"/>
        <source>1 hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="601"/>
        <location filename="view/systemcontrolwidget.cpp" line="722"/>
        <source>2 hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="602"/>
        <location filename="view/systemcontrolwidget.cpp" line="724"/>
        <source>3 hours</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatPowerManagePageOneListWidget</name>
    <message>
        <location filename="view/powermanagewidget.cpp" line="180"/>
        <location filename="view/powermanagewidget.cpp" line="293"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="181"/>
        <location filename="view/powermanagewidget.cpp" line="295"/>
        <source>1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="182"/>
        <location filename="view/powermanagewidget.cpp" line="297"/>
        <source>5 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="183"/>
        <location filename="view/powermanagewidget.cpp" line="299"/>
        <source>10 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="184"/>
        <location filename="view/powermanagewidget.cpp" line="301"/>
        <source>30 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="185"/>
        <location filename="view/powermanagewidget.cpp" line="303"/>
        <source>1 hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="186"/>
        <location filename="view/powermanagewidget.cpp" line="305"/>
        <source>2 hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="187"/>
        <location filename="view/powermanagewidget.cpp" line="307"/>
        <source>3 hours</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatPowerManagePageTwo</name>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="754"/>
        <location filename="view/systemcontrolwidget.cpp" line="869"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="755"/>
        <location filename="view/systemcontrolwidget.cpp" line="870"/>
        <source>1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="756"/>
        <location filename="view/systemcontrolwidget.cpp" line="871"/>
        <source>5 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="757"/>
        <location filename="view/systemcontrolwidget.cpp" line="873"/>
        <source>10 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="758"/>
        <location filename="view/systemcontrolwidget.cpp" line="875"/>
        <source>30 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="759"/>
        <location filename="view/systemcontrolwidget.cpp" line="877"/>
        <source>1 hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="760"/>
        <location filename="view/systemcontrolwidget.cpp" line="879"/>
        <source>2 hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="761"/>
        <location filename="view/systemcontrolwidget.cpp" line="881"/>
        <source>3 hours</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatPowerManagePageTwoListWidget</name>
    <message>
        <location filename="view/powermanagewidget.cpp" line="336"/>
        <location filename="view/powermanagewidget.cpp" line="449"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="337"/>
        <location filename="view/powermanagewidget.cpp" line="451"/>
        <source>1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="338"/>
        <location filename="view/powermanagewidget.cpp" line="453"/>
        <source>5 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="339"/>
        <location filename="view/powermanagewidget.cpp" line="455"/>
        <source>10 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="340"/>
        <location filename="view/powermanagewidget.cpp" line="457"/>
        <source>30 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="341"/>
        <location filename="view/powermanagewidget.cpp" line="459"/>
        <source>1 hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="342"/>
        <location filename="view/powermanagewidget.cpp" line="461"/>
        <source>2 hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/powermanagewidget.cpp" line="343"/>
        <location filename="view/powermanagewidget.cpp" line="463"/>
        <source>3 hours</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSetUnitListWidget</name>
    <message>
        <location filename="view/setunitwidget.cpp" line="8"/>
        <source>Length Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setunitwidget.cpp" line="9"/>
        <source>Temp Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setunitwidget.cpp" line="10"/>
        <location filename="view/setunitwidget.cpp" line="162"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSetUnitPageOne</name>
    <message>
        <location filename="view/setunitwidget.cpp" line="185"/>
        <location filename="view/setunitwidget.cpp" line="298"/>
        <source>Meter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setunitwidget.cpp" line="186"/>
        <location filename="view/setunitwidget.cpp" line="300"/>
        <source>Foot</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSetUnitPageTwo</name>
    <message>
        <location filename="view/setunitwidget.cpp" line="317"/>
        <location filename="view/setunitwidget.cpp" line="429"/>
        <source>Celsius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setunitwidget.cpp" line="318"/>
        <location filename="view/setunitwidget.cpp" line="431"/>
        <source>Fahrenheit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatShutterIntervalListWidget</name>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="8"/>
        <location filename="view/shutterintervalwidget.cpp" line="121"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="9"/>
        <location filename="view/shutterintervalwidget.cpp" line="123"/>
        <source>30 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="10"/>
        <location filename="view/shutterintervalwidget.cpp" line="125"/>
        <source>1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="11"/>
        <location filename="view/shutterintervalwidget.cpp" line="127"/>
        <source>5 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="12"/>
        <location filename="view/shutterintervalwidget.cpp" line="129"/>
        <source>10 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="13"/>
        <location filename="view/shutterintervalwidget.cpp" line="131"/>
        <source>30 minutes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatShutterIntervalPage</name>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="154"/>
        <location filename="view/shutterintervalwidget.cpp" line="274"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="155"/>
        <location filename="view/shutterintervalwidget.cpp" line="276"/>
        <source>Reelect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="156"/>
        <location filename="view/shutterintervalwidget.cpp" line="272"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="519"/>
        <source>%1 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="523"/>
        <source>%1 Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="525"/>
        <source>%1 Minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="529"/>
        <source>%1 Minute %2 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="531"/>
        <source>%1 Minutes %2 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatShutterIntervalSmallWidget</name>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="380"/>
        <location filename="view/shutterintervalwidget.cpp" line="476"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="391"/>
        <location filename="view/shutterintervalwidget.cpp" line="478"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="402"/>
        <location filename="view/shutterintervalwidget.cpp" line="481"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSysControlListWidget</name>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="9"/>
        <source>Video Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="11"/>
        <source>Laser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="13"/>
        <source>USB Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="16"/>
        <source>Screen saver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="17"/>
        <source>Timing shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="21"/>
        <location filename="view/systemcontrolwidget.cpp" line="173"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSysControlPageOne</name>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="189"/>
        <location filename="view/systemcontrolwidget.cpp" line="300"/>
        <source>MP4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="190"/>
        <location filename="view/systemcontrolwidget.cpp" line="302"/>
        <source>MP3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSysControlPageThree</name>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="462"/>
        <location filename="view/systemcontrolwidget.cpp" line="575"/>
        <source>USB1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="463"/>
        <location filename="view/systemcontrolwidget.cpp" line="577"/>
        <source>USB2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSysControlPageTwo</name>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="321"/>
        <location filename="view/systemcontrolwidget.cpp" line="438"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="322"/>
        <location filename="view/systemcontrolwidget.cpp" line="442"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSysListWidget</name>
    <message>
        <location filename="view/systemwidget.cpp" line="10"/>
        <source>Param Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="19"/>
        <source>System Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="28"/>
        <source>Image Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="37"/>
        <source>System Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="46"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSysStackPageFour</name>
    <message>
        <location filename="view/systemwidget.cpp" line="762"/>
        <source>Restore Factory Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="770"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="864"/>
        <source>Function not implemented!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSysStackPageOne</name>
    <message>
        <location filename="view/systemwidget.cpp" line="173"/>
        <source>Global Param</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="181"/>
        <source>Gear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="189"/>
        <source>Emiss Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="197"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSysStackPageThree</name>
    <message>
        <location filename="view/systemwidget.cpp" line="521"/>
        <source>Auto Shutter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="522"/>
        <location filename="view/systemwidget.cpp" line="546"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="532"/>
        <source>Auto Shutter Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="545"/>
        <source>Save Photo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="556"/>
        <source>Save Photo Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="523"/>
        <location filename="view/systemwidget.cpp" line="547"/>
        <location filename="view/systemwidget.cpp" line="600"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatSysStackPageTwo</name>
    <message>
        <location filename="view/systemwidget.cpp" line="320"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="328"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="337"/>
        <source>DateTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="346"/>
        <source>Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="355"/>
        <source>Unit Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="364"/>
        <source>Power Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/systemwidget.cpp" line="373"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatUpdatePage</name>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="532"/>
        <location filename="view/updateprogramwidget.cpp" line="647"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="533"/>
        <location filename="view/updateprogramwidget.cpp" line="649"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="534"/>
        <location filename="view/updateprogramwidget.cpp" line="651"/>
        <source>Recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="535"/>
        <location filename="view/updateprogramwidget.cpp" line="653"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="536"/>
        <location filename="view/updateprogramwidget.cpp" line="656"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatUpdateSmallWidget</name>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="361"/>
        <location filename="view/updateprogramwidget.cpp" line="489"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="374"/>
        <location filename="view/updateprogramwidget.cpp" line="491"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="387"/>
        <location filename="view/updateprogramwidget.cpp" line="493"/>
        <source>Recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="401"/>
        <location filename="view/updateprogramwidget.cpp" line="495"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="415"/>
        <location filename="view/updateprogramwidget.cpp" line="497"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatVideoBrowingSmallWidget</name>
    <message>
        <location filename="view/videowidget.cpp" line="272"/>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/videowidget.cpp" line="283"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/videowidget.cpp" line="294"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/videowidget.cpp" line="305"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SatVideoSmallWidget</name>
    <message>
        <location filename="view/videowidget.cpp" line="12"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/videowidget.cpp" line="25"/>
        <source>PauseAndPlay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/videowidget.cpp" line="39"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/videowidget.cpp" line="51"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/videowidget.cpp" line="62"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveADWidget</name>
    <message>
        <location filename="view/smallwidget.cpp" line="12"/>
        <source>Temp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="55"/>
        <source>AD:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="62"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="8"/>
        <source>SetAD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="68"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetAutoShutterWidget</name>
    <message>
        <location filename="view/smallwidget.cpp" line="600"/>
        <source>AutoShutter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="604"/>
        <source>Auto Shutter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="611"/>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="612"/>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="621"/>
        <source>Time(s):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="632"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetDateWidget</name>
    <message>
        <location filename="view/smallwidget.cpp" line="1041"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="1048"/>
        <source>Year:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="1065"/>
        <source>Month:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="1081"/>
        <source>Day:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="1108"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="1115"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetDisWidget</name>
    <message>
        <location filename="view/smallwidget.cpp" line="1323"/>
        <source>Set Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="1328"/>
        <source>Dis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="1336"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="1341"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetGearWidget</name>
    <message>
        <location filename="view/smallwidget.cpp" line="277"/>
        <source>SetGear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="296"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="302"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="281"/>
        <source>Range:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="287"/>
        <source>1st -20~250Â°C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="288"/>
        <source>2st 200~1000Â°C</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetParamWidget</name>
    <message>
        <location filename="view/setparamwidget.cpp" line="17"/>
        <source>SetParam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setparamwidget.cpp" line="22"/>
        <source>Fid:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setparamwidget.cpp" line="30"/>
        <source>Gsk:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setparamwidget.cpp" line="38"/>
        <source>Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setparamwidget.cpp" line="46"/>
        <source>INT:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setparamwidget.cpp" line="54"/>
        <source>DET:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setparamwidget.cpp" line="61"/>
        <source>Sensor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setparamwidget.cpp" line="68"/>
        <source>AD:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setparamwidget.cpp" line="75"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/setparamwidget.cpp" line="80"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetSerialNumberWidget</name>
    <message>
        <location filename="view/smallwidget.cpp" line="863"/>
        <source>SerialNumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="869"/>
        <source>Serial Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/smallwidget.cpp" line="880"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetUnitWidget</name>
    <message>
        <location filename="view/setunitwidget.cpp" line="454"/>
        <source>Unit Setting</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShowAdTableWidget</name>
    <message>
        <location filename="view/modifyadtablewidget.cpp" line="114"/>
        <location filename="view/modifyadtablewidget.cpp" line="169"/>
        <source>ShowADTable[%1]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShutterIntervalWidget</name>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="308"/>
        <source>Shutter Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="549"/>
        <source>Auto Shutter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/shutterintervalwidget.cpp" line="618"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SolidBar</name>
    <message>
        <location filename="view/solidbar.cpp" line="175"/>
        <source>%1Â°C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/solidbar.cpp" line="178"/>
        <source>%1Â°F</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemControlWidget</name>
    <message>
        <location filename="view/systemcontrolwidget.cpp" line="914"/>
        <source>Control</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemWidget</name>
    <message>
        <location filename="view/systemwidget.cpp" line="914"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabDialog</name>
    <message>
        <location filename="view/tabdialog.cpp" line="22"/>
        <source>KTable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabdialog.cpp" line="47"/>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabdialog.cpp" line="53"/>
        <source>TempAD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabdialog.cpp" line="58"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabdialog.cpp" line="62"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabdialog.cpp" line="67"/>
        <source>Calibration</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabPageFive</name>
    <message>
        <location filename="view/tabpage.cpp" line="715"/>
        <source>AutoInt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="716"/>
        <location filename="view/tabpage.cpp" line="730"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="717"/>
        <location filename="view/tabpage.cpp" line="731"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="729"/>
        <source>RecordArg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="743"/>
        <source>Distance</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabPageFour</name>
    <message>
        <location filename="view/tabpage.cpp" line="539"/>
        <source>Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="540"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="541"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="553"/>
        <source>Laser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="554"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="555"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="563"/>
        <source>Serial Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="571"/>
        <source>Set Factory Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="578"/>
        <source>Table To SD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="585"/>
        <source>SDToTable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabPageOne</name>
    <message>
        <location filename="view/tabpage.cpp" line="22"/>
        <source>Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="23"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="24"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="36"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="43"/>
        <source>Low Temp Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="50"/>
        <source>High Temp Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="57"/>
        <source>Save K Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="64"/>
        <source>Cal Bad Point</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabPageThree</name>
    <message>
        <location filename="view/tabpage.cpp" line="383"/>
        <source>Save AD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="390"/>
        <source>Update Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="397"/>
        <source>Take Effect Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="404"/>
        <source>Modify Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="411"/>
        <source>Show Table</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabPageTwo</name>
    <message>
        <location filename="view/tabpage.cpp" line="205"/>
        <source>Auto Shutter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="213"/>
        <source>Shutter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="214"/>
        <source>Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="215"/>
        <source>In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="227"/>
        <source>Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="228"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="229"/>
        <source>Spot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="237"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="238"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="239"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="247"/>
        <source>Set Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="248"/>
        <source>one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/tabpage.cpp" line="255"/>
        <source>Set Param</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateProgramWidget</name>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="708"/>
        <source>Update Program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="716"/>
        <source>Available update package:%1
Size:%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="831"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="832"/>
        <source>Do you want to update this package?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="838"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="839"/>
        <source>Confirm the backup program?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="845"/>
        <source>Recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="846"/>
        <source>Did you restore the last backup?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="852"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="855"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="894"/>
        <source> No update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="898"/>
        <source> File lost or damaged!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="907"/>
        <source>%1 K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="911"/>
        <source>%1 KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="913"/>
        <source>%1 M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/updateprogramwidget.cpp" line="916"/>
        <source> Update package name:

	%1
 The size:

	%2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideoBrowingWidget</name>
    <message>
        <location filename="view/videowidget.cpp" line="411"/>
        <source>Video Browing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="view/videowidget.cpp" line="518"/>
        <source>The Video will be deleted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
